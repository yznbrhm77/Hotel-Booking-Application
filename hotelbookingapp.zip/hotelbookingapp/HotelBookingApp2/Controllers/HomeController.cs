﻿using Microsoft.AspNetCore.Mvc;

public class HomeController : Controller
{
    private HotelContext db = new HotelContext();

    public ActionResult Index()
    {
        var rooms = db.Rooms.ToList();
        return View(rooms);
    }
}
