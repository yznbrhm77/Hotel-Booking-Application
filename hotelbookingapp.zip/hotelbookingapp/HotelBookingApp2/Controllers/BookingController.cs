﻿using Microsoft.AspNetCore.Mvc;

public class BookingController : Controller
{
    private HotelContext db = new HotelContext();

    public ActionResult Create(int roomId)
    {
        var room = db.Rooms.Find(roomId);
        if (room == null)
        {
            return HttpNotFound();
        }

        ViewBag.Room = room;
        return View();
    }

    private ActionResult HttpNotFound()
    {
        throw new NotImplementedException();
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public ActionResult Create([Bind(Include = "RoomId,CustomerId,CheckInDate,CheckOutDate")] Booking booking)
    {
        if (ModelState.IsValid)
        {
            db.Bookings.Add(booking);
            db.SaveChanges();
            return RedirectToAction("Index", "Home");
        }

        var room = db.Rooms.Find(booking.RoomId);
        ViewBag.Room = room;
        return View(booking);
    }
}
