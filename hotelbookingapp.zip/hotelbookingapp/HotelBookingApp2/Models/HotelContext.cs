﻿

public class HotelContext : DbContext
{
    public DbSet<Room> Rooms { get; set; }
    public DbSet<Booking> Bookings { get; set; }
    public DbSet<Customer> Customers { get; set; }

    internal void SaveChanges()
    {
        throw new NotImplementedException();
    }
}
